EC2 Instance: http://18.218.8.194/ (Port 80)
Hello World: Port 3000
GitHub Repo: https://github.com/ualbany-csi518/assignment-1-AbrahamZak